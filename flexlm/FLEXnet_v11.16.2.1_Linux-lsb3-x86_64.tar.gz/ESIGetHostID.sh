#!/bin/sh
#
# Checking FlexNet details
# =========================
REVISION="02-May-2019"
# ==================
unset LD_LIBRARY_PATH

SCRIPTNAME=`readlink -f $0`
DIRNAME=`dirname ${SCRIPTNAME}`

if [ "$1" = "showhelp" ]; then
  printf "Show details for FlexNet License Server configuration\n"
else
  printf "******************************************************\n"
  printf "* FlexNet configuration for `uname -n`\n"
  printf "*                                   (Rev. ${REVISION})\n"
  printf "******************************************************\n"

# Hardware Model
  if [ -r /sys/devices/virtual/dmi/id/sys_vendor ]; then
    SYSTEMVENDOR=`cat /sys/devices/virtual/dmi/id/sys_vendor`
    if [ -r /sys/devices/virtual/dmi/id/product_name ]; then
      SYSTEMPRODUCT=`cat /sys/devices/virtual/dmi/id/product_name`
      printf "Hardware Model ......: ${SYSTEMPRODUCT} (${SYSTEMVENDOR})\n"
    fi
  else
    LSHAL=`which lshal 2>/dev/null | awk '{ print $NF; }'`
    if [ -n "${LSHAL}" ]; then
      SYSTEMVENDOR=`${LSHAL} 2>/dev/null | grep system.hardware.vendor | cut -f2 -d\'`
      SYSTEMPRODUCT=`${LSHAL} 2>/dev/null | grep system.hardware.product | cut -f2 -d\'`
      SMBIOSMAN=`${LSHAL} 2>/dev/null | grep smbios.system.manufacturer | cut -f2 -d\'`
      SMBIOSPRODUCT=`${LSHAL} 2>/dev/null | grep smbios.system.product | cut -f2 -d\'`
      if [ -n "${SMBIOSPRODUCT}" ]; then
        printf "Hardware Model ......: ${SMBIOSPRODUCT} (${SMBIOSMAN})\n"
      elif [ -n "${SYSTEMPRODUCT}" ]; then
        printf "Hardware Model ......: ${SYSTEMPRODUCT} (${SYSTEMVENDOR})\n"
      fi
    fi
  fi

# Linux Operating system name
  printf "Operating System ....: "
  LSBRELEASE=/usr/bin/lsb_release
  RELEASEFILE=/etc/os-release
  if [ -x "${LSBRELEASE}" ]; then
    for printrel in `${LSBRELEASE} -d | cut -f2 -d:`; do
      printf "${printrel} "
    done
    printf "\n"
    PRINTOS=1
  elif [ -r ${RELEASEFILE} ]; then
    . ${RELEASEFILE}
    if [ -n "${PRETTY_NAME}" ]; then
      printf "${PRETTY_NAME}\n"
      PRINTOS=1
    fi
  else
    printf "\n"
  fi
  if [ -z "${PRINTOS}" ]; then
    for release in /etc/*release; do
      if [ ! -h ${release} ]; then
        printf " -> [${release}] "
        for printrel in `cat ${release}`; do printf "${printrel} "; done
        printf "\n"
      fi
    done		
  fi

# LSB3 OS Compliant
  printf "LSB3 OS Compliant ...: "
  case `uname -m` in
    i686 )
      if [ -x /lib/ld-lsb.so.3 ]; then
        printf "Yes\n"
      else
        printf "No\n"
        LSBWARNMSG=1
        NOFLEXDIR=1
      fi
      ;;

    x86_64 )
      if [ -x /lib64/ld-lsb-x86-64.so.3 ]; then
        printf "Yes\n"
      else
        printf "No\n"
        LSBWARNMSG=1
        NOFLEXDIR=1
      fi
      ;;

    ia64 )
      if [ -x /lib/ld-lsb-ia64.so.3 ]; then
        printf "Yes\n"
      else
        printf "No\n"
      fi
      ;;
  esac
  if [ -n "${LSBWARNMSG}" ]; then
    printf "\n  WARNING: Your Operating System is not LSB3 compliant.\n   This is required by FlexNet Licensing utilities.\n\n"
  fi


# FlexNet repository
  printf "FlexNet repository ..: "
  if [ -x "${DIRNAME}/lmutil" ]; then
    printf "${DIRNAME}\n"
    LMUTIL=${DIRNAME}/lmutil
    LMGRD=${DIRNAME}/lmgrd
    PAMLMD=${DIRNAME}/pam_lmd
  elif [ ! -d "$PAMHOME/flexnet" ]; then
    printf "\$PAMHOME/flexnet not found!\n"
    NOFLEXDIR=1
  elif [ -x "$PAMHOME/getppgdir.sh" ]; then
    FLEXPLATFORM=`$PAMHOME/getppgdir.sh flex`
    printf "\$PAMHOME/flexnet/${FLEXPLATFORM}\n"
    if [ ! -d "$PAMHOME/flexnet/${FLEXPLATFORM}" ]; then
      printf "\n\n  WARNING: $PAMHOME/flexnet/${FLEXPLATFORM} does not exist.\n"
      printf "    Please check that this system is officially supported.\n\n"
      NOFLEXDIR=1
    else
      LMUTIL=$PAMHOME/flexnet/${FLEXPLATFORM}/lmutil
      LMGRD=$PAMHOME/flexnet/${FLEXPLATFORM}/lmgrd
      PAMLMD=$PAMHOME/flexnet/${FLEXPLATFORM}/pam_lmd
    fi
  else
    printf "Unknown (\$PAMHOME/getppgdir.sh not present)\n"
    NOFLEXDIR=1
  fi

  if [ -n "$NOFLEXDIR" ]; then
    printf "\n\n  Please check your installation or support of this Operating System.\n"

  else

    printf "\n\n"

# FlexNet version:
    if [ -x "${LMUTIL}" ]; then
      
      printf "FlexNet Licensing utilities version:\n"
      UTILVER=`${LMUTIL} lmver ${LMUTIL} | tail -1 | cut -f1 -d','`
      printf "lmutil: $UTILVER\n"
      if [ -x "${LMGRD}" ]; then
        LMGRDVER=`${LMUTIL} lmver ${LMGRD} | tail -1 | cut -f1 -d','`
        printf "lmgrd: $LMGRDVER\n"
      fi
      if [ -x "${PAMLMD}" ]; then
        PAMLMDVER=`${LMUTIL} lmver ${PAMLMD} | tail -1 | cut -f1 -d','`
        printf "pam_lmd: $PAMLMDVER\n"
      fi

      # FNPLicensingService status (Virtual Machine only)
      CHASSISTYPE=`${LMUTIL} lmvminfo | tail -1`
      case ${CHASSISTYPE} in
        *Virtual* )
          STATFNPLS=`${LMUTIL} lmver -fnls | tail -1`
          printf "FNPLicensingService: ${STATFNPLS}\n"
          ;;
      esac

      printf "\n\n"
      printf "FlexNet details for this host:\n"
      FLEXHOST=`${LMUTIL} lmhostid -hostdomain -n | cut -f2 -d=`
      printf "Hostname.........: ${FLEXHOST}\n"

      if [ -n "${CHASSISTYPE}" ]; then
        printf "Chassis Type.....: ${CHASSISTYPE}\n"
      fi
      
      FLEXIP=`${LMUTIL} lmhostid -internet v4 -n | cut -f2 -d=`
      if [ -n "${FLEXIP}" ]; then
        printf "IPv4 Address.....: ${FLEXIP}\n"
      fi

      FLEXIPV6=`${LMUTIL} lmhostid -internet v6 -n | cut -f2 -d=`
      if [ -n "${FLEXIPV6}" ]; then
        printf "IPv6 Address.....: ${FLEXIP}\n"
      fi

      printf "Possible HostIDs.: \n"
      case ${CHASSISTYPE} in
        *Physical* )
          FLEXPHYETHER=`${LMUTIL} lmhostid -ptype PHY -n`
          printf "   ${FLEXPHYETHER}\n"
          ;;

        *Virtual* )
          FLEXETHER=`${LMUTIL} lmhostid -n`
          if [ $? -eq 0 ]; then
            printf "   ${FLEXETHER} "
            SECONDCHOICE="\n   === or ===\n   "
          fi
          FLEXVMUUID=`${LMUTIL} lmhostid -ptype VM -n`
          if [ $? -eq 0 ]; then
            printf "${SECONDCHOICE}${FLEXVMUUID}\n"
          else
            printf "\n\nINFO: The FlexNet Licensing Service must be started.\n"
            printf "  This is required to obtain VM_UUID Host ID type on Virtual Platforms.\n"
            printf "  Install it by running following script as root:\n"
            if [ -x "${DIRNAME}/install_fnp.sh" ]; then
              printf "    cd ${DIRNAME}\n    sudo ./install_fnp.sh --cert\n\n"
            elif [ $PAMHOME/flexnet/${FLEXPLATFORM}/install_fnp.sh ]; then
              printf "    cd $PAMHOME/flexnet/${FLEXPLATFORM}\n    sudo ./install_fnp.sh --cert\n\n"
            fi
          fi
          ;;
      esac
    fi
  fi
fi

